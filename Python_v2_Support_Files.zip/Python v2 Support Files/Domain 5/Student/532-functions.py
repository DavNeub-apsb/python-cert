# build a function to multiply a score and a multiplier
def calculate_score(score, multiplier):
    return(score * multiplier)

print(calculate_score(3000,2)) #expect 6000
print(calculate_score(3200,1.5)) #expect 4800