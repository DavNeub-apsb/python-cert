plant_types = ['angiosperms','ferns','mosses']
print(plant_types[0])
print(plant_types[3])