score = 3000
bonus = score/10 #300 on this test
multiplier = 2

print(score + bonus * multiplier) #expecting 6600