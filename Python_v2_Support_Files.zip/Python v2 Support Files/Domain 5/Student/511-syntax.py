# build a function to multiply a score and a multiplier
def calculate_score(score, multiplier)
    print('score upcoming')
     return(score * multiplier)
    
print(calculate_score(3000,2)
print(calculate_score(3200,1.5))