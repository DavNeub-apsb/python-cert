#dictionary example
coins = {
    "gold":100,
    "silver":50,
    "bronze":25
}
print(coins)

#set example
regions = {"north","south","east"}

print(regions)

#tuple example
char1_name=("Humphrey",'Cat')
char1_name[1]="Dog"
