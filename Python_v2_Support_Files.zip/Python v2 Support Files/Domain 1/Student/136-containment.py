large_islands = ["Hokkaido", "Honshu", "Shikoku", "Kyushu"]
island1 = "Hokkaido"
print(island1 in large_islands)