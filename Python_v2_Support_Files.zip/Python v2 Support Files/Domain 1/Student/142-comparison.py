player1_score = 300
player2_score = 400
player3_score = 300

print(player1_score != player2_score)
print(player1_score < player3_score)
print(player1_score > player2_score)