x = 5
y = 3

print (x + y)

print (x - y)

print (x * y)

print (x / y)

print (x // y)

print (x % y)

print (x ** y)

print( x + 2 * y)

