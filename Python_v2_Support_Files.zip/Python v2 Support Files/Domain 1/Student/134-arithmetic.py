base = 4000
rank = 3
bonus = 500

total_score = base + bonus * rank
print(total_score)
