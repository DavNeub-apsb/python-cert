capitals=["Montgomery","Juneau"]
first_name="Star"
last_name="Metal"
print(capitals)