score = 300

score += 10  
print(score)



x = y = 2
y = 2
