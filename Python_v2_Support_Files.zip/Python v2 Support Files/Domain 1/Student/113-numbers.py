number_of_tries = 3
multiplier = 1.5

print(number_of_tries / multiplier)