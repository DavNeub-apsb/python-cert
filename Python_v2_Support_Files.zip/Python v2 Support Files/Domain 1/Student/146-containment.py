ancient_civilizations = ['Mesopotamia','Egypt','Indus Valley','China']

print('Egypt' in ancient_civilizations)
print('Japan' in ancient_civilizations)
print('China' in ancient_civilizations)