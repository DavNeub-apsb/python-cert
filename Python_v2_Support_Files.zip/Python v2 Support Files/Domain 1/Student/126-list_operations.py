capitals=["Montgomery","Juneau","Phoenix"]


print(capitals)
