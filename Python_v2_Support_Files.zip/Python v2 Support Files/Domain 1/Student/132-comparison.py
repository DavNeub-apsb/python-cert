x = 5
y = 3
print (x == y)
print (x <= y > 2)