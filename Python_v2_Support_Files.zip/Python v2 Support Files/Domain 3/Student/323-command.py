message = open('323-message.txt','w')
message.write('Testing file for player configuration\n')
message.write('Testing file for player score\n')
message.close()
print("Message file complete")

