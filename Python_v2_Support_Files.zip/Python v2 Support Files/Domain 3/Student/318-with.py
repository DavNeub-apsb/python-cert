message = open('318-message.txt','w')
message.write('Testing file for player configuration\n')
message.write('Testing file for player score\n')
message.close()


