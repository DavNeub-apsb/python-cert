message = open('314-message.txt','w')
message.write('Testing file for player configuration')
message.write('Testing file for player score')
message.close()

