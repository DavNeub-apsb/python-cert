player_name = input("Please enter your first name.")
print("Welcome to the game",player_name)