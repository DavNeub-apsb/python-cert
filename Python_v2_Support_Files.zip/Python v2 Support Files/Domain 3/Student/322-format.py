score = 200000
level = 3
player1 = "Stacey"

print("Player1:", player1, "Score:", score, "Level:", level)
