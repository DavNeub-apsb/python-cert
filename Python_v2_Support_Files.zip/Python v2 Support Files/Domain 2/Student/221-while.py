score = 0
score_increase = 10

while score <= 100:
   print("You have", score, "points.") 
   score += score_increase

