coins = ('Bronze','Silver','Gold')
for coin in coins:
    print ('You possess a', coin, 'coin.')