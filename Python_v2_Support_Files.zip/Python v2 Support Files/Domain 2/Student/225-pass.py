coins = ('Bronze','Silver','Platinum','Gold')
for coin in coins:

    if coin == 'Platinum':
        print("Congratulations. Your platinum coin will move you to the next level.")
        continue
    print ('You possess a', coin, 'coin.')