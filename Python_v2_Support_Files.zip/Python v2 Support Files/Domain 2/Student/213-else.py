score = 4000

if score > 10000:
    print("You have reached level 2")
elif score > 5000:
    print("You have reached level 1")
