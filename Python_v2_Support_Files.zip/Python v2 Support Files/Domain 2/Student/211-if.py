score = 15000

if score > 10000:
    print("You have reached level 2")
print("Thank you for playing")