positions = 10
for p in range(1,10):
    print ("You are in position", p)

for m in range(1,27):
    print("You have reached mile", m)
