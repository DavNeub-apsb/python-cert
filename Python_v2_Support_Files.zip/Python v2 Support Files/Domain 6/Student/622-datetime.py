import datetime
current_time = #current date and time
print("The current date and time is:", # date in mm-dd-yy)
