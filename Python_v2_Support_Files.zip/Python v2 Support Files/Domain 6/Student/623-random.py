from random import randrange
for i in range(10):
    print(randrange(5,20))