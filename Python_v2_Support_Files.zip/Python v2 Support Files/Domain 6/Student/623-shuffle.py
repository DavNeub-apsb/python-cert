import random
categories = ['Acids','Bases','PH Numbers']
random.shuffle(categories)

print(categories)

