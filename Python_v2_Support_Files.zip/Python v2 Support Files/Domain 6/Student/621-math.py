import math

x=3.33
y=-12

print(math.fabs(y))

#print(math.ceil(x))

#print(math.floor(x))

#print(math.trunc(x))

#print(math.trunc(y))

#print(math.fmod(y,x))

#print(math.frexp(x))

#print(math.isnan(x))

#print(x*y)

#print(math.sqrt(x))

#print(math.isqrt(x))

#print(math.pow(y,x))

#print(math.pi)

#print(math.pi * math.pow(x, 2))