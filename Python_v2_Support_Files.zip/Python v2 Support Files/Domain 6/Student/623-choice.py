import random
categories = ['Acids','Bases','PH Numbers']
category = random.sample(categories,2)

print(category)