import sys

game_lives = 1
while game_lives < 3:
    print("Game in progress")
    game_lives +=1
sys.exit()