def total_score(score, multiplier):
    return score * multiplier

print(total_score(3000,1.5))
print(total_score(4000,2))