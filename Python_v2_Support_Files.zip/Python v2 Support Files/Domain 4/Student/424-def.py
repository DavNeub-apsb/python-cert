# build a function to multiply a score and a multiplier




