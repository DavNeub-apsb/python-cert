def calculate_total(amount,license,tax):
    pass

def get_amounts():
    amount = int(input("Enter amount "))
    license = int(input("Enter license amount "))
    print("The total is", calculate_total)
    print(amount)

subtotal = get_amounts()